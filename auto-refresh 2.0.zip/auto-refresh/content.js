let intervalTime = 60000; // 默认刷新间隔 1 分钟
let refreshTimer = null;
let countdownTimer = null;
let nextRefreshAt = 0;
let countdownEl = null;
let clockCanvas = null;
let clockDigital = null;
let isClockVisible = false;
let clockRaf = 0;
let lastIntervalTime = intervalTime;

function createOrUpdateCountdownUI() {
    if (!countdownEl) {
        countdownEl = document.createElement('div');
        countdownEl.id = 'auto-refresh-countdown-ui';
        countdownEl.className = 'exclude-dark-mode';
        countdownEl.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: rgba(0, 0, 0, 0.7);
            color: #fff;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 14px;
            font-family: monospace;
            z-index: 2147483647;
            pointer-events: auto;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            backdrop-filter: blur(4px);
            transition: opacity 0.3s;
            user-select: none;
            cursor: default;
        `;
        countdownEl.innerHTML = `
          <div id="auto-refresh-countdown-badge"></div>
          <div id="auto-refresh-countdown-popover" style="
            position: absolute;
            right: 0;
            bottom: calc(100% + 10px);
            width: 220px;
            padding: 12px;
            background: rgba(255, 255, 255, 0.96);
            color: #000;
            border: 1px solid rgba(0,0,0,0.35);
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.25);
            display: none;
          ">
            <div style="display:flex; justify-content:center;">
              <canvas id="auto-refresh-clock" width="160" height="160" style="display:block;"></canvas>
            </div>
            <div id="auto-refresh-clock-digital" style="
              margin-top: 8px;
              text-align: center;
              font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;
              font-size: 13px;
              color: #111;
              letter-spacing: 0.3px;
            "></div>
          </div>
        `;
        document.body.appendChild(countdownEl);

        const popover = countdownEl.querySelector('#auto-refresh-countdown-popover');
        clockCanvas = countdownEl.querySelector('#auto-refresh-clock');
        clockDigital = countdownEl.querySelector('#auto-refresh-clock-digital');

        countdownEl.addEventListener('mouseenter', () => {
            isClockVisible = true;
            if (popover) popover.style.display = 'block';
            startClockRaf();
        });
        countdownEl.addEventListener('mouseleave', () => {
            isClockVisible = false;
            if (popover) popover.style.display = 'none';
            stopClockRaf();
        });
    }
    
    const badge = countdownEl.querySelector('#auto-refresh-countdown-badge');
    const remainingMs = Math.max(0, nextRefreshAt - Date.now());
    const totalSeconds = Math.ceil(remainingMs / 1000);
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    const timeStr = m > 0 ? `${m}:${s.toString().padStart(2, '0')}` : `${s}s`;
    if (badge) badge.textContent = `刷新: ${timeStr}`;
    countdownEl.style.display = 'block';
}

function removeCountdownUI() {
    if (countdownEl) {
        countdownEl.style.display = 'none';
    }
}

function formatRemainingMs(remainingMs) {
    const totalMs = Math.max(0, Math.floor(remainingMs));
    const totalSeconds = Math.floor(totalMs / 1000);
    const ms = totalMs % 1000;
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${ms.toString().padStart(3, '0')}`;
}

function drawClock(remainingMs) {
    if (!clockCanvas) return;
    const ctx = clockCanvas.getContext('2d');
    if (!ctx) return;
    const w = clockCanvas.width;
    const h = clockCanvas.height;
    const cx = w / 2;
    const cy = h / 2;
    const r = Math.min(cx, cy) - 6;

    ctx.clearRect(0, 0, w, h);

    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#111';
    ctx.stroke();

    for (let i = 0; i < 60; i++) {
        const ang = (i / 60) * Math.PI * 2 - Math.PI / 2;
        const len = i % 5 === 0 ? 10 : 5;
        const lw = i % 5 === 0 ? 2.2 : 1.2;
        const x1 = cx + Math.cos(ang) * (r - len);
        const y1 = cy + Math.sin(ang) * (r - len);
        const x2 = cx + Math.cos(ang) * r;
        const y2 = cy + Math.sin(ang) * r;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.lineWidth = lw;
        ctx.strokeStyle = '#111';
        ctx.stroke();
    }

    const remaining = Math.max(0, remainingMs);
    const seconds = (remaining / 1000) % 60;
    const minutes = (remaining / 1000 / 60) % 60;
    const hours = (remaining / 1000 / 3600) % 12;

    const secAng = (seconds / 60) * Math.PI * 2 - Math.PI / 2;
    const minAng = (minutes / 60) * Math.PI * 2 - Math.PI / 2;
    const hourAng = (hours / 12) * Math.PI * 2 - Math.PI / 2;

    const drawHand = (ang, length, width, color) => {
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + Math.cos(ang) * length, cy + Math.sin(ang) * length);
        ctx.lineWidth = width;
        ctx.lineCap = 'round';
        ctx.strokeStyle = color;
        ctx.stroke();
    };

    drawHand(hourAng, r * 0.48, 5, '#111');
    drawHand(minAng, r * 0.68, 3.5, '#111');
    drawHand(secAng, r * 0.78, 2, '#111');

    ctx.beginPath();
    ctx.arc(cx, cy, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#111';
    ctx.fill();
}

function startClockRaf() {
    if (clockRaf) return;
    const tick = () => {
        clockRaf = requestAnimationFrame(tick);
        const remainingMs = Math.max(0, nextRefreshAt - Date.now());
        drawClock(remainingMs);
        if (clockDigital) clockDigital.textContent = formatRemainingMs(remainingMs);
    };
    tick();
}

function stopClockRaf() {
    if (clockRaf) {
        cancelAnimationFrame(clockRaf);
        clockRaf = 0;
    }
}

function scheduleReload() {
    const remaining = Math.max(0, nextRefreshAt - Date.now());
    if (refreshTimer) {
        clearTimeout(refreshTimer);
        refreshTimer = null;
    }
    refreshTimer = setTimeout(() => {
        location.reload();
    }, remaining);
}

function start() {
    if (!nextRefreshAt) nextRefreshAt = Date.now() + intervalTime;
    createOrUpdateCountdownUI();

    if (!countdownTimer) {
        countdownTimer = setInterval(() => {
            createOrUpdateCountdownUI();
            if (!isClockVisible && clockDigital) {
                clockDigital.textContent = '';
            }
        }, 100);
    }

    if (!refreshTimer) {
        scheduleReload();
    }
}

function stop() {
    if (refreshTimer) {
        clearTimeout(refreshTimer);
        refreshTimer = null;
    }
    if (countdownTimer) {
        clearInterval(countdownTimer);
        countdownTimer = null;
    }
    stopClockRaf();
    removeCountdownUI();
}

function applyWebDarkMode(enable) {
    if (enable) {
        if (!document.getElementById('auto-refresh-web-dark-mode')) {
            const style = document.createElement('style');
            style.id = 'auto-refresh-web-dark-mode';
            // 使用 CSS 滤镜强行反色，并保留图片的原始颜色
            style.textContent = `
                html {
                    filter: invert(100%) hue-rotate(180deg) !important;
                    background: #fff !important; 
                }
                img, video, iframe, canvas, svg, .exclude-dark-mode {
                    filter: invert(100%) hue-rotate(180deg) !important;
                }
            `;
            document.head.appendChild(style);
        }
    } else {
        const style = document.getElementById('auto-refresh-web-dark-mode');
        if (style) style.remove();
    }
}

function checkStatus() {
    chrome.storage.local.get(['enabled', 'interval', 'refreshScope', 'webDarkMode'], (res) => {
        if (res.interval) intervalTime = res.interval;
        const intervalChanged = intervalTime !== lastIntervalTime;
        lastIntervalTime = intervalTime;
        
        // 护眼模式
        applyWebDarkMode(!!res.webDarkMode);

        const scope = res.refreshScope || 'current'; // 默认仅当前页面
        let shouldRun = false;
        
        if (scope === 'all' && res.enabled) {
            shouldRun = true;
        } else if (scope === 'current' && sessionStorage.getItem('autoRefreshEnabled') === 'true') {
            shouldRun = true;
        }

        if (shouldRun) {
            if (intervalChanged) {
                nextRefreshAt = Date.now() + intervalTime;
                scheduleReload();
            }
            start();
        } else {
            stop();
        }
    });
}

// 页面加载时同步状态
checkStatus();

// 监听 storage 改变 (用于响应时间间隔或全局启停)
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
        checkStatus();
    }
});

// 监听来自 popup / background 的独立消息 (用于单页面启停)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'start_current') {
        sessionStorage.setItem('autoRefreshEnabled', 'true');
        checkStatus();
        sendResponse({status: "started"});
    } else if (msg.action === 'stop_current') {
        sessionStorage.removeItem('autoRefreshEnabled');
        checkStatus();
        sendResponse({status: "stopped"});
    } else if (msg.action === 'apply_web_dark_mode') {
        applyWebDarkMode(msg.enable);
        sendResponse({status: "ok"});
    }
});
